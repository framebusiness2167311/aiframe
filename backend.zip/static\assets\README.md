# Assets

All customizable icons and sounds for the AI Coach app live here.
Swap any file and reload the app — no code changes needed (except for the inline SVG buttons, noted below).

---

## Icons — `icons/`

### PWA App Icons

Shown on the home screen, browser tab, and push notifications.

| File | Size | Used in |
|------|------|---------|
| `icons/icon.svg` | any (vector) | `manifest.json`, `sw.js` |
| `icons/icon-192.png` | 192×192 | `manifest.json` |
| `icons/icon-512.png` | 512×512 | `manifest.json` |

**To swap:** Replace the files here, keeping the same filenames.

---

### UI Button Icons (inline SVG)

These live inline inside `<button>` elements in `index.html` so CSS can control their fill color.
The SVG files here are the source — to swap, update **both** the file here and the matching `<path d="...">` in `index.html`.

#### `icons/mic.svg` — Microphone
- **Element:** `#mic-btn` in `index.html` (search `assets/icons/mic.svg`)
- **States:** default = `var(--text-dim)`, recording = white on red background
- **To swap:** Copy your new SVG's path data into `#mic-btn > svg > path` in `index.html`, then update `icons/mic.svg` to match.

#### `icons/send.svg` — Send / paper plane
- **Element:** `#send-btn` in `index.html` (search `assets/icons/send.svg`)
- **To swap:** Same process as mic — update the path in `index.html` and the file here.

---

### Emoji Icons

Hardcoded characters in `index.html`. Find and replace to change.

| Emoji | Element ID | Purpose |
|-------|-----------|---------|
| ⚡ | `#header-icon` | Taps to open the side drawer |
| 🔊 | `#voice-btn .icon-wrap` | Toggle voice/speaker |
| 💬 | `#empty-icon` | Chat empty state |
| ✅ | Drawer — Tasks header | Section label |

---

### Animated Icon

`#wave-icon` — 5 CSS `<span>` bars that pulse when the assistant is speaking.
Pure CSS, no image file. Edit the `#wave-icon` block in `index.html` to change the animation.

---

## Sounds — `sounds/`

The app uses Web Audio API tones by default (no files required).
To use custom sounds, drop your audio files here with the exact filenames below.
Supported formats: `.mp3`, `.ogg`, `.wav` (tried in that order).

| Filename | When it plays | Default tone |
|----------|--------------|--------------|
| `sounds/mic-start` | Mic button pressed — recording begins | 880 Hz short blip |
| `sounds/mic-stop` | Recording ends (manually or after speech) | 440 Hz short blip |
| `sounds/notification` | AI coach reply received | Two-note chime (660 → 880 Hz) |

**To swap:** Drop `mic-start.mp3`, `mic-stop.mp3`, or `notification.mp3` into `sounds/`.
The app checks for the file first; if not found, it falls back to the built-in tone automatically.

**To disable a sound entirely:** Add a silent audio file (0.1s of silence as MP3/WAV) with that name.
