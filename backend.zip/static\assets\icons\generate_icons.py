"""
generate_icons.py — Single source of truth for app icons.

To change the icon:
  1. Edit icon.svg (in this folder)
  2. Run: python generate_icons.py

This regenerates:
  - icon-192.png                               (web PWA)
  - icon-512.png                               (web PWA)
  - Android mipmap-*/ic_launcher.png           (launcher icon)
  - Android mipmap-*/ic_launcher_round.png     (round launcher icon)
  - Android drawable-*/ic_coach.png            (home avatar, chat header, menu button)

And patches layout XML to replace any emoji/placeholder icon with @drawable/ic_coach:
  - fragment_coach_menu.xml  (Coach Menu header)
"""

import cairosvg, os, re

HERE  = os.path.dirname(os.path.abspath(__file__))
SVG   = os.path.join(HERE, 'icon.svg')
RES   = os.path.join(HERE, '../../../03_add_features_part1/android/app/src/main/res')

def make(size, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    cairosvg.svg2png(url=SVG, write_to=path, output_width=size, output_height=size)
    print(f'  ok {os.path.relpath(path, HERE)}')

print('Generating web icons...')
make(192, os.path.join(HERE, 'icon-192.png'))
make(512, os.path.join(HERE, 'icon-512.png'))

print('Generating Android launcher icons...')
for folder, size in [
    ('mipmap-mdpi',    48),
    ('mipmap-hdpi',    72),
    ('mipmap-xhdpi',   96),
    ('mipmap-xxhdpi',  144),
    ('mipmap-xxxhdpi', 192),
]:
    make(size, os.path.join(RES, folder, 'ic_launcher.png'))
    make(size, os.path.join(RES, folder, 'ic_launcher_round.png'))

print('Generating Android in-app icons...')
for folder, size in [
    ('drawable-mdpi',    48),
    ('drawable-hdpi',    72),
    ('drawable-xhdpi',   96),
    ('drawable-xxhdpi',  144),
    ('drawable-xxxhdpi', 192),
]:
    make(size, os.path.join(RES, folder, 'ic_coach.png'))

print('Patching Android layout XML...')

LAYOUTS = [
    os.path.join(RES, 'layout', 'fragment_coach_menu.xml'),
]

# Pattern: a TextView used purely as an icon (no id, short text/emoji, small textSize)
# Replace with a standard ImageView using @drawable/ic_coach
EMOJI_ICON_PATTERN = re.compile(
    r'<TextView\s[^>]*android:text="[^"]{1,4}"[^>]*android:textSize="1[0-9]sp"[^/]*/>'
    , re.DOTALL
)
IMAGE_VIEW_REPLACEMENT = (
    '<ImageView\n'
    '            android:layout_width="24dp"\n'
    '            android:layout_height="24dp"\n'
    '            android:src="@drawable/ic_coach"\n'
    '            android:contentDescription="Coach icon" />'
)

for layout_path in LAYOUTS:
    if not os.path.exists(layout_path):
        print(f'  skip (not found): {os.path.relpath(layout_path, HERE)}')
        continue
    with open(layout_path, 'r', encoding='utf-8') as f:
        content = f.read()
    # Only patch if still using an emoji placeholder (not already an ImageView with ic_coach)
    if '@drawable/ic_coach' not in content:
        patched = EMOJI_ICON_PATTERN.sub(IMAGE_VIEW_REPLACEMENT, content, count=1)
        if patched != content:
            with open(layout_path, 'w', encoding='utf-8') as f:
                f.write(patched)
            print(f'  patched {os.path.relpath(layout_path, HERE)}')
        else:
            print(f'  no emoji icon found to patch: {os.path.relpath(layout_path, HERE)}')
    else:
        print(f'  already correct: {os.path.relpath(layout_path, HERE)}')

print('\nAll icons generated.')
