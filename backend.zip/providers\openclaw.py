import asyncio
import base64
import hashlib
import json
import time
import uuid
from pathlib import Path

import websockets
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import (
    Encoding, NoEncryption, PrivateFormat, PublicFormat,
    load_pem_private_key, load_pem_public_key,
)

DEVICE_DIR = Path(__file__).parent / ".openclaw-device"
PAIRING_RETRIES = 6
PAIRING_RETRY_DELAY = 5


class _PairingPending(Exception):
    pass


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def _ensure_device_identity() -> tuple[str, str, str]:
    """Generate and persist an Ed25519 keypair. Returns (device_id, priv_pem, pub_pem)."""
    DEVICE_DIR.mkdir(exist_ok=True)
    key_path = DEVICE_DIR / "key.pem"
    pub_path = DEVICE_DIR / "pub.pem"

    if key_path.exists() and pub_path.exists():
        priv_pem = key_path.read_text()
        pub_pem = pub_path.read_text()
    else:
        pk = Ed25519PrivateKey.generate()
        priv_pem = pk.private_bytes(Encoding.PEM, PrivateFormat.PKCS8, NoEncryption()).decode()
        pub_pem = pk.public_key().public_bytes(Encoding.PEM, PublicFormat.SubjectPublicKeyInfo).decode()
        key_path.write_text(priv_pem)
        pub_path.write_text(pub_pem)

    raw_pub = load_pem_public_key(pub_pem.encode()).public_bytes(Encoding.Raw, PublicFormat.Raw)
    device_id = hashlib.sha256(raw_pub).hexdigest()
    return device_id, priv_pem, pub_pem


class OpenClawProvider:
    def __init__(self, ws_url: str, token: str = "", agent: str = "main"):
        url = ws_url.rstrip("/")
        if url.startswith("http://"):
            url = "ws://" + url[7:]
        elif url.startswith("https://"):
            url = "wss://" + url[8:]
        if not url.startswith("ws://") and not url.startswith("wss://"):
            url = "ws://" + url
        if not url.endswith("/gateway"):
            url = url + "/gateway"
        self.url = url
        self.token = token
        self.agent = agent or "main"

    async def _connect_and_chat(self, last_user: str, device_id: str,
                                 priv_pem: str, pub_pem: str) -> str:
        """Single connection attempt: handshake + chat."""
        async with websockets.connect(self.url, open_timeout=30) as ws:
            # 1. Receive connect.challenge
            raw = await asyncio.wait_for(ws.recv(), timeout=15)
            challenge = json.loads(raw)

            if challenge.get("event") != "connect.challenge":
                raise RuntimeError("OpenClaw error — unexpected handshake")

            nonce = challenge["payload"]["nonce"]

            # 2. Build signed connect request
            role = "operator"
            scopes = ["operator.read", "operator.write"]
            signed_at_ms = int(time.time() * 1000)

            sign_payload = "|".join([
                "v2", device_id, "cli", "cli", role,
                ",".join(scopes), str(signed_at_ms),
                self.token, nonce,
            ])
            key = load_pem_private_key(priv_pem.encode(), password=None)
            signature = _b64url(key.sign(sign_payload.encode("utf-8")))
            pub_key_raw = load_pem_public_key(pub_pem.encode()).public_bytes(
                Encoding.Raw, PublicFormat.Raw
            )

            connect_id = str(uuid.uuid4())
            await ws.send(json.dumps({
                "type": "req",
                "id": connect_id,
                "method": "connect",
                "params": {
                    "minProtocol": 3,
                    "maxProtocol": 3,
                    "client": {
                        "id": "cli",
                        "version": "1.0.0",
                        "platform": "windows",
                        "mode": "cli",
                    },
                    "role": role,
                    "scopes": scopes,
                    "caps": [],
                    "commands": [],
                    "permissions": {},
                    "auth": {"token": self.token} if self.token else {},
                    "locale": "en-US",
                    "userAgent": "ai-coach/1.0.0",
                    "device": {
                        "id": device_id,
                        "publicKey": _b64url(pub_key_raw),
                        "signature": signature,
                        "signedAt": signed_at_ms,
                        "nonce": nonce,
                    },
                },
            }))

            # 3. Wait for hello-ok
            raw = await asyncio.wait_for(ws.recv(), timeout=15)
            hello = json.loads(raw)

            if not hello.get("ok"):
                err = hello.get("error", {})
                code = err.get("details", {}).get("code", "")
                if code == "PAIRING_REQUIRED":
                    raise _PairingPending()
                msg = err.get("message", "").lower()
                if any(w in msg for w in ("auth", "token", "pairing", "device")):
                    raise RuntimeError("OpenClaw pairing required")
                raise RuntimeError("OpenClaw error — try again")

            # 4. Send chat.send
            chat_id = str(uuid.uuid4())
            session_key = str(uuid.uuid4())
            await ws.send(json.dumps({
                "type": "req",
                "id": chat_id,
                "method": "chat.send",
                "params": {
                    "sessionKey": session_key,
                    "idempotencyKey": str(uuid.uuid4()),
                    "message": last_user,
                },
            }))

            # 5. Collect response
            content = ""
            while True:
                try:
                    timeout = 10 if content else 120
                    raw = await asyncio.wait_for(ws.recv(), timeout=timeout)
                except asyncio.TimeoutError:
                    if content:
                        break
                    raise
                frame = json.loads(raw)
                ft = frame.get("type", "")
                fe = frame.get("event", "")

                # Skip keepalive frames
                if fe in ("tick", "health"):
                    continue

                if ft == "res" and frame.get("id") == chat_id:
                    if not frame.get("ok"):
                        raise RuntimeError("OpenClaw error — try again")
                    p = frame.get("payload", {})
                    if "content" in p:
                        content = p["content"]
                        break
                    continue

                if ft == "event":
                    p = frame.get("payload", {})
                    data = p.get("data", {})
                    stream = p.get("stream", "")

                    if fe == "agent" and stream == "assistant":
                        if "text" in data:
                            content = data["text"]

                    if fe == "agent" and stream == "lifecycle":
                        if data.get("phase") == "end":
                            break

                    if p.get("done") or p.get("finished"):
                        break
                    if fe in ("chat.done", "agent.done", "done"):
                        break

            if not content:
                raise RuntimeError("OpenClaw error — empty response")
            return content

    async def chat(self, history: list[dict], task_context: str | None = None) -> str:
        last_user = next(
            (m["content"] for m in reversed(history) if m["role"] == "user"),
            ""
        )
        if not last_user:
            raise RuntimeError("OpenClaw error — try again")
        if task_context:
            last_user = task_context + "\n\n" + last_user

        try:
            device_id, priv_pem, pub_pem = _ensure_device_identity()

            for attempt in range(PAIRING_RETRIES + 1):
                try:
                    return await self._connect_and_chat(
                        last_user, device_id, priv_pem, pub_pem
                    )
                except _PairingPending:
                    if attempt < PAIRING_RETRIES:
                        await asyncio.sleep(PAIRING_RETRY_DELAY)
                    else:
                        raise RuntimeError("OpenClaw pairing required — approve this device in OpenClaw")

        except RuntimeError:
            raise
        except (websockets.exceptions.ConnectionClosed, websockets.exceptions.InvalidHandshake):
            raise RuntimeError("OpenClaw connection lost")
        except asyncio.TimeoutError:
            raise RuntimeError("OpenClaw timed out — try again")
        except OSError:
            raise RuntimeError("is OpenClaw running")
        except Exception:
            raise RuntimeError("OpenClaw error — try again")
