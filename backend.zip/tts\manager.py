"""Kokoro TTS manager — downloads model bundle and generates speech audio."""

from __future__ import annotations

import asyncio
import bz2
import importlib
import logging
import shutil
import subprocess
import sys
import tarfile
import time
import uuid
import wave
from enum import Enum
from pathlib import Path
from typing import Optional

import httpx

log = logging.getLogger("tts")

# Stable URL from official k2-fsa repo (tts-models tag — permanent)
_BUNDLE_URL = (
    "https://github.com/k2-fsa/sherpa-onnx/releases/download/"
    "tts-models/kokoro-int8-en-v0_19.tar.bz2"
)
_BUNDLE_SIZE = 98_000_000  # ~98MB compressed

# Expected files after extraction (inside kokoro-int8-en-v0_19/ dir)
_REQUIRED_FILES = ["model.onnx", "tokens.txt", "voices.bin"]


class TtsStatus(Enum):
    NOT_INSTALLED = "not_installed"
    INSTALLING = "installing"
    READY = "ready"
    ERROR = "error"


# Voice name -> speaker-ID (must match Android app exactly)
SPEAKER_IDS: dict[str, int] = {
    "af_heart": 0,
    "af_alloy": 1, "af_aoede": 2, "af_bella": 3,
    "af_jessica": 4, "af_kore": 5, "af_nicole": 6,
    "af_nova": 7, "af_river": 8, "af_sarah": 9, "af_sky": 10,
    "am_adam": 11, "am_echo": 12, "am_eric": 13,
    "am_fenrir": 14, "am_liam": 15, "am_michael": 16,
    "am_onyx": 17, "am_puck": 18,
    "bf_alice": 19, "bf_emma": 20, "bf_isabella": 21, "bf_lily": 22,
    "bm_daniel": 23, "bm_fable": 24, "bm_george": 25, "bm_lewis": 26,
}


class KokoroTtsManager:
    """Manages Kokoro TTS model download, loading, and audio generation."""

    def __init__(self, base_dir: Path) -> None:
        self._base_dir = base_dir
        self._model_dir = base_dir / "tts_models" / "kokoro"
        self._audio_dir = base_dir / "tts_audio"
        self._audio_dir.mkdir(parents=True, exist_ok=True)

        self._status = TtsStatus.NOT_INSTALLED
        self._progress: float = 0.0
        self._error_message: str = ""
        self._status_message: str = ""
        self._tts = None

        # If model already present, load immediately
        if self._model_files_exist():
            try:
                self._load_engine()
                self._status = TtsStatus.READY
            except Exception as exc:
                self._status = TtsStatus.ERROR
                self._error_message = str(exc)

    # -- Public properties --

    @property
    def status(self) -> TtsStatus:
        return self._status

    @property
    def progress(self) -> float:
        return self._progress

    @property
    def error_message(self) -> str:
        return self._error_message

    @property
    def status_message(self) -> str:
        return self._status_message

    # -- Install (dependencies + download + extract + load) --

    async def install(self) -> None:
        self._status = TtsStatus.INSTALLING
        self._progress = 0.0
        self._error_message = ""
        self._status_message = "Starting installation..."

        try:
            # Phase 1: pip dependencies
            await self._ensure_dependencies()

            # Phase 2: download bundle
            if not self._model_files_exist():
                await self._download_bundle()

            # Phase 3: load engine
            self._status_message = "Loading voice engine..."
            self._progress = 0.96
            await asyncio.to_thread(self._load_engine)
            self._progress = 1.0
            self._status_message = "Ready"
            self._status = TtsStatus.READY
        except Exception as exc:
            self._status = TtsStatus.ERROR
            self._error_message = str(exc)
            self._status_message = f"Error: {exc}"
            log.error("TTS install failed: %s", exc)

    async def _ensure_dependencies(self) -> None:
        missing = []
        for pkg in ("sherpa_onnx", "numpy"):
            try:
                importlib.import_module(pkg)
            except ImportError:
                missing.append(pkg.replace("_", "-"))

        if not missing:
            log.info("TTS dependencies already installed")
            return

        self._status_message = f"Installing packages: {', '.join(missing)}..."
        log.info("Installing missing packages: %s", missing)
        cmd = [sys.executable, "-m", "pip", "install", "--quiet", *missing]
        proc = await asyncio.to_thread(
            subprocess.run, cmd, capture_output=True, text=True, timeout=600
        )
        if proc.returncode != 0:
            raise RuntimeError(
                f"pip install failed: {proc.stderr.strip() or proc.stdout.strip()}"
            )
        importlib.invalidate_caches()
        self._progress = 0.10
        log.info("Dependencies installed successfully")

    async def _download_bundle(self) -> None:
        self._model_dir.mkdir(parents=True, exist_ok=True)
        tmp_tar = self._model_dir / "bundle.tar.bz2"
        downloaded = 0

        self._status_message = "Downloading voice model..."
        async with httpx.AsyncClient(follow_redirects=True, timeout=600) as client:
            async with client.stream("GET", _BUNDLE_URL) as resp:
                resp.raise_for_status()
                with open(tmp_tar, "wb") as f:
                    async for chunk in resp.aiter_bytes(chunk_size=65_536):
                        f.write(chunk)
                        downloaded += len(chunk)
                        self._progress = min(0.10 + 0.80 * downloaded / _BUNDLE_SIZE, 0.90)
                        mb = downloaded // 1_000_000
                        total_mb = _BUNDLE_SIZE // 1_000_000
                        self._status_message = f"Downloading voice model... {mb}MB / {total_mb}MB"

        # Extract
        self._status_message = "Extracting model files..."
        self._progress = 0.92
        await asyncio.to_thread(self._extract_bundle, tmp_tar)
        tmp_tar.unlink(missing_ok=True)
        self._progress = 0.95

    def _extract_bundle(self, tar_path: Path) -> None:
        with tarfile.open(str(tar_path), "r:bz2") as tar:
            tar.extractall(path=str(self._model_dir.parent))
        # The tar extracts to a subdirectory like kokoro-int8-en-v0_19/
        # Move contents to our model_dir
        extracted_dirs = [
            d for d in self._model_dir.parent.iterdir()
            if d.is_dir() and d.name.startswith("kokoro") and d != self._model_dir
        ]
        if extracted_dirs:
            src = extracted_dirs[0]
            if self._model_dir.exists():
                shutil.rmtree(self._model_dir)
            src.rename(self._model_dir)
            log.info("Extracted model to %s", self._model_dir)

    # -- Audio generation --

    async def generate_audio(
        self,
        text: str,
        voice: str = "af_heart",
        speed: float = 1.0,
    ) -> Optional[str]:
        if self._status != TtsStatus.READY or self._tts is None:
            return None

        sid = SPEAKER_IDS.get(voice, 0)
        filename = f"{uuid.uuid4()}.wav"
        out_path = self._audio_dir / filename

        try:
            await asyncio.to_thread(self._synthesize, text, sid, speed, out_path)
            return f"/tts/audio/{filename}"
        except Exception as exc:
            log.error("TTS generation failed: %s", exc)
            return None

    # -- Cleanup --

    def cleanup_audio(self, max_age_seconds: int = 300) -> None:
        now = time.time()
        for f in self._audio_dir.glob("*.wav"):
            try:
                if now - f.stat().st_mtime > max_age_seconds:
                    f.unlink()
            except OSError:
                pass

    # -- Internal --

    def _model_files_exist(self) -> bool:
        return all((self._model_dir / name).exists() for name in _REQUIRED_FILES)

    def _load_engine(self) -> None:
        import sherpa_onnx

        # espeak-ng-data: prefer bundled (from tar), fallback to sherpa-onnx package
        espeak_data = self._model_dir / "espeak-ng-data"
        if not espeak_data.is_dir():
            espeak_data = Path(sherpa_onnx.__file__).parent / "espeak-ng-data"
        if not espeak_data.is_dir():
            raise RuntimeError("espeak-ng-data not found")

        tts_config = sherpa_onnx.OfflineTtsConfig(
            model=sherpa_onnx.OfflineTtsModelConfig(
                kokoro=sherpa_onnx.OfflineTtsKokoroModelConfig(
                    model=str(self._model_dir / "model.onnx"),
                    voices=str(self._model_dir / "voices.bin"),
                    tokens=str(self._model_dir / "tokens.txt"),
                    data_dir=str(espeak_data),
                ),
                num_threads=2,
                provider="cpu",
            ),
        )
        self._tts = sherpa_onnx.OfflineTts(tts_config)

    def _synthesize(self, text: str, sid: int, speed: float, out_path: Path) -> None:
        import numpy as np

        audio = self._tts.generate(text, sid=sid, speed=speed)
        if audio.samples is None or len(audio.samples) == 0:
            raise RuntimeError("TTS produced no audio samples")

        samples = np.array(audio.samples, dtype=np.float32)
        pcm16 = (samples * 32767).clip(-32768, 32767).astype(np.int16)

        with wave.open(str(out_path), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(audio.sample_rate)
            wf.writeframes(pcm16.tobytes())
