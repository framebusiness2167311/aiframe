import httpx

GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
MODEL = "llama-3.3-70b-versatile"
SYSTEM_PROMPT = (
    "You are a demanding personal AI coach and life organiser. "
    "You keep the user on top of their tasks, habits, and goals. "
    "Be direct and honest. Call out failures plainly. Give genuine praise only when earned. "
    "No softening, no filler, no feel-good fluff. Keep replies short and actionable."
)


class GroqProvider:
    def __init__(self, api_key: str):
        self.api_key = api_key

    async def chat(self, history: list[dict], task_context: str | None = None) -> str:
        system = SYSTEM_PROMPT
        if task_context:
            system += "\n\n" + task_context
        messages = [{"role": "system", "content": system}] + history
        async with httpx.AsyncClient() as client:
            r = await client.post(
                GROQ_URL,
                json={"model": MODEL, "messages": messages},
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=60,
            )
        if r.status_code == 401:
            raise RuntimeError("check your Groq API key")
        if r.status_code == 429:
            raise RuntimeError("Groq rate limit reached")
        if r.status_code != 200:
            raise RuntimeError(f"Groq error {r.status_code} — try again")
        try:
            return r.json()["choices"][0]["message"]["content"]
        except (KeyError, IndexError, ValueError):
            raise RuntimeError("Groq error — try again")
