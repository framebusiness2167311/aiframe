import os
os.environ["BACKEND_SECRET"] = "test_secret_abc123"

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, AsyncMock
from main import app

client = TestClient(app)

def test_missing_token_returns_401():
    response = client.post("/api/chat", json={"message": "hi", "session_id": "s1"})
    assert response.status_code == 401

def test_wrong_token_returns_401():
    response = client.post(
        "/api/chat",
        json={"message": "hi", "session_id": "s1"},
        headers={"X-App-Token": "wrong_token"}
    )
    assert response.status_code == 401

def test_missing_provider_returns_400():
    response = client.post(
        "/api/chat",
        json={"message": "hi", "session_id": "s1"},
        headers={"X-App-Token": "test_secret_abc123"}
    )
    assert response.status_code == 400

def test_groq_missing_key_returns_400():
    response = client.post(
        "/api/chat",
        json={"message": "hi", "session_id": "s1"},
        headers={
            "X-App-Token": "test_secret_abc123",
            "X-Provider": "groq",
            "X-Provider-Key": ""
        }
    )
    assert response.status_code == 400

def test_openclaw_missing_url_returns_400():
    response = client.post(
        "/api/chat",
        json={"message": "hi", "session_id": "s1"},
        headers={
            "X-App-Token": "test_secret_abc123",
            "X-Provider": "openclaw",
            "X-Provider-Url": ""
        }
    )
    assert response.status_code == 400

def test_groq_chat_returns_reply():
    with patch("main.GroqProvider") as MockProvider:
        mock_instance = MockProvider.return_value
        mock_instance.chat = AsyncMock(return_value="Do the work.")
        response = client.post(
            "/api/chat",
            json={"message": "help me", "session_id": "s1"},
            headers={
                "X-App-Token": "test_secret_abc123",
                "X-Provider": "groq",
                "X-Provider-Key": "gsk_test"
            }
        )
    assert response.status_code == 200
    assert response.json()["reply"] == "Do the work."
