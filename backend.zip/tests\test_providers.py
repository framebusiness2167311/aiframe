import pytest
import respx
import httpx
from providers.groq import GroqProvider

SYSTEM_PROMPT = (
    "You are a demanding personal AI coach and life organiser. "
    "You keep the user on top of their tasks, habits, and goals. "
    "Be direct and honest. Call out failures plainly. Give genuine praise only when earned. "
    "No softening, no filler, no feel-good fluff. Keep replies short and actionable."
)

@pytest.mark.asyncio
@respx.mock
async def test_groq_returns_reply():
    respx.post("https://api.groq.com/openai/v1/chat/completions").mock(
        return_value=httpx.Response(200, json={
            "choices": [{"message": {"content": "Get it done."}}]
        })
    )
    provider = GroqProvider(api_key="gsk_test")
    reply = await provider.chat([{"role": "user", "content": "Help me"}])
    assert reply == "Get it done."

@pytest.mark.asyncio
@respx.mock
async def test_groq_401_raises_with_message():
    respx.post("https://api.groq.com/openai/v1/chat/completions").mock(
        return_value=httpx.Response(401)
    )
    provider = GroqProvider(api_key="gsk_bad")
    with pytest.raises(Exception, match="check your Groq API key"):
        await provider.chat([{"role": "user", "content": "Help"}])

@pytest.mark.asyncio
@respx.mock
async def test_groq_429_raises_with_message():
    respx.post("https://api.groq.com/openai/v1/chat/completions").mock(
        return_value=httpx.Response(429)
    )
    provider = GroqProvider(api_key="gsk_test")
    with pytest.raises(Exception, match="rate limit"):
        await provider.chat([{"role": "user", "content": "Help"}])

@pytest.mark.asyncio
@respx.mock
async def test_groq_500_raises_generic():
    respx.post("https://api.groq.com/openai/v1/chat/completions").mock(
        return_value=httpx.Response(500)
    )
    provider = GroqProvider(api_key="gsk_test")
    with pytest.raises(Exception, match="try again"):
        await provider.chat([{"role": "user", "content": "Help"}])

@pytest.mark.asyncio
@respx.mock
async def test_groq_malformed_response_raises():
    respx.post("https://api.groq.com/openai/v1/chat/completions").mock(
        return_value=httpx.Response(200, json={"unexpected": "structure"})
    )
    provider = GroqProvider(api_key="gsk_test")
    with pytest.raises(Exception, match="try again"):
        await provider.chat([{"role": "user", "content": "Help"}])
