@echo off
echo Killing any existing process on port 8000...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :8000 ^| findstr LISTENING') do taskkill /PID %%a /F 2>nul

echo Starting backend...
cd /d C:\charlie_superpowers_app\backend
start "AI Coach Backend" python main.py

echo Waiting for backend to start...
timeout /t 3 /nobreak >nul

echo Starting Cloudflare Tunnel...
if exist "C:\cloudflared\tunnel.log" del "C:\cloudflared\tunnel.log"
start "Cloudflare Tunnel" cmd /c "C:\cloudflared\cloudflared-windows-amd64.exe tunnel --url http://localhost:8000 > C:\cloudflared\tunnel.log 2>&1"

echo Waiting for tunnel URL (usually ~10 seconds)...
:WAIT_URL
timeout /t 2 /nobreak >nul
powershell -Command ^
  "$log = 'C:\cloudflared\tunnel.log';" ^
  "$kt = 'C:\charlie_superpowers_app\android\app\src\main\java\com\charlieclief\aicoach\network\RetrofitClient.kt';" ^
  "$kt2 = 'C:\charlie_superpowers_app\.worktrees\flexible-ai-provider\android\app\src\main\java\com\charlieclief\aicoach\network\RetrofitClient.kt';" ^
  "$c = if (Test-Path $log) { Get-Content $log -Raw } else { '' };" ^
  "if ($c -match 'https://[a-z0-9-]+\.trycloudflare\.com') {" ^
  "  $url = $matches[0] + '/';" ^
  "  $kt_content = Get-Content $kt -Raw;" ^
  "  $kt_content = $kt_content -replace 'private const val BASE_URL = \".*?\"', ('private const val BASE_URL = \"' + $url + '\"');" ^
  "  Set-Content $kt $kt_content -NoNewline;" ^
  "  if (Test-Path $kt2) {" ^
  "    $kt2_content = Get-Content $kt2 -Raw;" ^
  "    $kt2_content = $kt2_content -replace 'private const val BASE_URL = \".*?\"', ('private const val BASE_URL = \"' + $url + '\"');" ^
  "    Set-Content $kt2 $kt2_content -NoNewline;" ^
  "  }" ^
  "  Write-Host '';" ^
  "  Write-Host ('  Tunnel URL: ' + $url);" ^
  "  Write-Host '  RetrofitClient.kt updated automatically.';" ^
  "  exit 0" ^
  "}; exit 1" 2>nul
if errorlevel 1 goto WAIT_URL

echo.
pause
