import asyncio
import uuid
import json
import httpx
import os
from datetime import datetime
from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
from pydantic import BaseModel
from pywebpush import webpush, WebPushException
from pathlib import Path
from dotenv import load_dotenv
from providers.groq import GroqProvider
from providers.openclaw import OpenClawProvider
from tts.manager import KokoroTtsManager

load_dotenv()

# ── VAPID keys (kept for PWA backwards compat) ──
_keys_path = Path(__file__).parent / "vapid_keys.json"
_keys = json.loads(_keys_path.read_text())
VAPID_PUBLIC_KEY  = _keys["public"]
VAPID_PRIVATE_KEY = _keys["private_key"]
VAPID_CLAIMS      = {"sub": "mailto:coach@local.app"}

# ── File paths ──
_subs_path       = Path(__file__).parent / "push_subscriptions.json"
_fcm_tokens_path = Path(__file__).parent / "fcm_tokens.json"
_cred_path       = Path(__file__).parent / "firebase-credentials.json"

# ── Storage helpers ──
def _load_json(path, default):
    if path.exists():
        try:
            return json.loads(path.read_text())
        except Exception:
            pass
    return default

def _save_json(path, data):
    path.write_text(json.dumps(data, indent=2))

def _load_subs():  return _load_json(_subs_path, [])
def _save_subs(v): _save_json(_subs_path, v)

# ── Firebase / FCM ──
try:
    import firebase_admin
    from firebase_admin import credentials, messaging
    _FIREBASE_AVAILABLE = True
except ImportError:
    _FIREBASE_AVAILABLE = False
    print("WARNING: firebase-admin not installed. FCM push disabled.")

def _init_firebase() -> bool:
    if not _FIREBASE_AVAILABLE:
        return False
    # Check for placeholder file — treat as missing
    if not _cred_path.exists():
        print("WARNING: firebase-credentials.json not found. FCM disabled.")
        return False
    raw = _load_json(_cred_path, {})
    if raw.get("_PLACEHOLDER"):
        print("WARNING: firebase-credentials.json is a placeholder. FCM disabled.")
        return False
    try:
        if not firebase_admin._apps:
            cred = credentials.Certificate(str(_cred_path))
            firebase_admin.initialize_app(cred)
        return bool(firebase_admin._apps)
    except Exception as e:
        print(f"WARNING: Firebase init failed: {e}")
        return False

def _fire_fcm(title: str, body: str, screen: str = "chat"):
    tokens = _load_json(_fcm_tokens_path, [])
    if not tokens or not _init_firebase():
        # Fall back to VAPID if no FCM tokens or Firebase not configured
        _fire_push(title, body)
        return
    dead = []
    for token in tokens:
        try:
            message = messaging.Message(
                notification=messaging.Notification(title=title, body=body),
                data={"screen": screen},
                token=token,
            )
            messaging.send(message)
        except Exception as e:
            print(f"FCM send failed for token: {e}")
            dead.append(token)
    if dead:
        _save_json(_fcm_tokens_path, [t for t in tokens if t not in dead])

# ── VAPID push helper (PWA backwards compat) ──
def _fire_push(title: str, body: str):
    subs = _load_subs()
    if not subs:
        return
    payload = json.dumps({"title": title, "body": body})
    dead = []
    for sub in subs:
        try:
            webpush(
                subscription_info={"endpoint": sub["endpoint"], "keys": sub["keys"]},
                data=payload,
                vapid_private_key=VAPID_PRIVATE_KEY,
                vapid_claims=VAPID_CLAIMS,
            )
        except WebPushException as e:
            print(f"Push failed: {e}")
            dead.append(sub["endpoint"])
    if dead:
        _save_subs([s for s in subs if s["endpoint"] not in dead])

@asynccontextmanager
async def lifespan(app):
    yield

app = FastAPI(lifespan=lifespan)

BACKEND_SECRET = os.environ["BACKEND_SECRET"]

sessions: dict[str, list] = {}

tts_manager = KokoroTtsManager(Path(__file__).parent)


# ── Models ──
class ChatRequest(BaseModel):
    message: str
    session_id: str = ""
    task_context: str | None = None

class PushSubscription(BaseModel):
    endpoint: str
    keys: dict

class PushMessage(BaseModel):
    title: str = "AI Coach"
    body: str

class DeviceRegistration(BaseModel):
    token: str

class FcmPushMessage(BaseModel):
    title: str = "AI Coach"
    body: str
    screen: str = "chat"


# ── Chat ──
@app.post("/api/chat")
async def chat(body: ChatRequest, request: Request):
    # Auth
    token = request.headers.get("X-App-Token", "")
    if not token or token != BACKEND_SECRET:
        raise HTTPException(status_code=401, detail="Unauthorized")

    # Provider validation
    provider_type  = request.headers.get("X-Provider", "")
    provider_key   = request.headers.get("X-Provider-Key", "")
    provider_url   = request.headers.get("X-Provider-Url", "")
    provider_agent = request.headers.get("X-Provider-Agent", "main")

    if provider_type == "groq" and not provider_key:
        raise HTTPException(status_code=400, detail="Missing X-Provider-Key for Groq")
    if provider_type == "openclaw" and not provider_url:
        raise HTTPException(status_code=400, detail="Missing X-Provider-Url for OpenClaw")
    if provider_type not in ("groq", "openclaw"):
        raise HTTPException(status_code=400, detail=f"Unknown provider: {provider_type}")

    # Session
    session_id = body.session_id or str(uuid.uuid4())
    if session_id not in sessions:
        sessions[session_id] = []
    history = sessions[session_id]
    history.append({"role": "user", "content": body.message})

    # Route to provider
    try:
        if provider_type == "openclaw":
            provider = OpenClawProvider(ws_url=provider_url, token=provider_key, agent=provider_agent)
        else:
            provider = GroqProvider(api_key=provider_key)
        reply = await provider.chat(history, task_context=body.task_context)
    except RuntimeError as e:
        history.pop()
        msg = str(e)
        if "check your Groq API key" in msg:
            return {"reply": "Coach unavailable — check your Groq API key.", "session_id": session_id}
        if "rate limit" in msg:
            return {"reply": "Coach unavailable — Groq rate limit reached.", "session_id": session_id}
        if "is OpenClaw running" in msg:
            return {"reply": "Coach unavailable — is OpenClaw running?", "session_id": session_id}
        if "pairing required" in msg:
            return {"reply": "Coach unavailable — OpenClaw pairing required.", "session_id": session_id}
        return {"reply": "Coach unavailable — try again.", "session_id": session_id}
    except Exception:
        history.pop()
        return {"reply": "Coach unavailable — try again.", "session_id": session_id}

    history.append({"role": "assistant", "content": reply})
    if len(history) > 40:
        sessions[session_id] = history[-40:]

    audio_url = None
    if tts_manager.status.value == "ready":
        audio_url = await tts_manager.generate_audio(reply)
        tts_manager.cleanup_audio()

    response = {"reply": reply, "session_id": session_id}
    if audio_url:
        response["audio_url"] = audio_url
    return response


# ── VAPID / PWA push (backwards compat) ──
@app.get("/api/vapid-public-key")
def get_vapid_public_key():
    return {"key": VAPID_PUBLIC_KEY}

@app.post("/api/subscribe")
def subscribe(sub: PushSubscription):
    _save_subs([{"endpoint": sub.endpoint, "keys": sub.keys}])
    return {"status": "subscribed"}

@app.post("/api/push")
def send_push(msg: PushMessage):
    subs = _load_subs()
    if not subs:
        raise HTTPException(status_code=404, detail="No subscribers")
    _fire_push(msg.title, msg.body)
    return {"status": "sent"}


# ── FCM device registration ──
@app.post("/api/register-device")
def register_device(reg: DeviceRegistration):
    tokens = _load_json(_fcm_tokens_path, [])
    if reg.token not in tokens:
        tokens.append(reg.token)
        _save_json(_fcm_tokens_path, tokens)
        print(f"Registered FCM token: {reg.token[:20]}...")
    return {"status": "registered"}


# ── FCM push (internal / server-triggered) ──
@app.post("/api/push-fcm")
def send_fcm_push(msg: FcmPushMessage):
    tokens = _load_json(_fcm_tokens_path, [])
    if not tokens:
        raise HTTPException(status_code=404, detail="No registered devices")
    _fire_fcm(msg.title, msg.body, msg.screen)
    return {"status": "sent"}


# ── Device-side store (PWA persistence) ──
_store_path = Path(__file__).parent / "store.json"

@app.get("/api/store")
def get_store():
    return _load_json(_store_path, {})

@app.post("/api/store")
async def save_store(request: Request):
    data = await request.json()
    _save_json(_store_path, data)
    return {"status": "saved"}


# ── TTS status / install ──
@app.get("/api/tts/status")
async def tts_status(request: Request):
    token = request.headers.get("X-App-Token", "")
    if not token or token != BACKEND_SECRET:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return {
        "status": tts_manager.status.value,
        "progress": tts_manager.progress,
        "message": tts_manager.status_message or tts_manager.error_message,
    }

@app.post("/api/tts/install")
async def tts_install(request: Request):
    token = request.headers.get("X-App-Token", "")
    if not token or token != BACKEND_SECRET:
        raise HTTPException(status_code=401, detail="Unauthorized")
    if tts_manager.status.value not in ("not_installed", "error"):
        return {"status": tts_manager.status.value, "progress": tts_manager.progress, "message": ""}
    # Start install in background
    asyncio.create_task(tts_manager.install())
    return {"status": "installing", "progress": 0.0, "message": ""}


(Path(__file__).parent / "tts_audio").mkdir(exist_ok=True)
app.mount("/tts/audio", StaticFiles(directory="tts_audio"), name="tts_audio")

app.mount("/", StaticFiles(directory="static", html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
